# R-Visagie-S-Vena-T-Tshabalala-R-Crous
A dating simulation game( Title still pending) where the user interacts with pre-designed characters in the hopes of "dating" characters.
